﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace WebApplication1.Controllers
{
    public class StudentController : Controller
    {
        // GET: Student
        public ActionResult Index()
        {
            return View();
        }

        [Route(Name = "Test")]
        public ActionResult Studentinfo() =>
            //DB
            View();

        public ActionResult Footer()
        {
            // DB
            return View();

        }
    }
}