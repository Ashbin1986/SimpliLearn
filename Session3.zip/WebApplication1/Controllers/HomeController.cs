﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Web;
using System.Web.Mvc;
using WebApplication1.Models;

namespace WebApplication1.Controllers
{
    public class HomeController : Controller
    {
        public ActionResult Index()
        {
          
            ViewData["ErrorMessage"] = TempData["ErrorMessage"];
            return View();
        }

        public ActionResult About()
        {
            ViewBag.Message = "Your application description page.";
           
            return View();
        }

        public ActionResult Contact()
        {
            ViewBag.Message = "Your contact page.";

            return View();
        }

        public ActionResult SaveStudent(Student student)
        {
            if(ModelState.IsValid)
            {
                // Process to DB
            }
            else
            {
                StringBuilder sb = new StringBuilder();
                if (String.IsNullOrEmpty(student.StudentName))
                {
                    sb.AppendFormat("Student name is required");
                   // sb.AppendFormat("<br/>");
                }
                if (String.IsNullOrEmpty(student.Address))
                {
                    sb.AppendFormat("Address is required");
                  //  sb.AppendFormat("<b/>");
                }


                TempData["ErrorMessage"] = sb.ToString();
            }


            ViewBag.Message = "Your contact page.";

            return RedirectToAction("Index");
        }
    }
}

