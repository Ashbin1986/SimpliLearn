﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace WEBAPIOlderWay.Models
{
    public class Product
    {
        public string productName { get; set; }
        public string productDescription { get; set; }
    }

    public class ProductRequest : Product
    {
        [Required]
        [Range(minimum:1,maximum:100 , ErrorMessage ="Recordid id must be between 1 to 100")]
        public int productid { get; set; }
    }
    public class Category
    {
        public string categoryName { get; set; }
    }
    public class CategoryProductRequest
    {
        public Category category { get; set; }
        public Product product { get; set; }
    }

    public class ResponseModel
    {
        public string Message { get; set; }
        public string StatusCode { get; set; }
        public bool IsSuccess { get; set; }

        public string ErrorDescription { get; set; }

    }
}