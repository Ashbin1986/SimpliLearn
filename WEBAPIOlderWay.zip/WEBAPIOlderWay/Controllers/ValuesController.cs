﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using WEBAPIOlderWay.Models;

namespace WEBAPIOlderWay.Controllers
{

    public class ValuesController : ApiController
    {
        // GET api/values
        public IEnumerable<string> Get()
        {
            return new string[] { "value1", "value2" };
        }

        // GET api/values/5
        //[Route("products/{id}/{pid}/getproducts")]
        //public List<ProductViewModel> Get(int id, int pid)
        [Route("products/{id}/getproducts")]
        public List<ProductViewModel> Get(int id)
        {

            List<ProductViewModel> productViewModels = new List<ProductViewModel>();

            using (ECommerceDBEntities context = new ECommerceDBEntities())
            {
                var response = context.GetProductDetails(id).ToList();

                foreach (var item in response)
                {
                    productViewModels.Add(new ProductViewModel
                    {
                        CategoryId = item.CategoryId,
                        CategoryName = item.CategoryName,
                        ProductDescription = item.ProductDescription,
                        ProductId = item.ProductId,
                        ProductName = item.ProductName
                    });
                }
            }
            return productViewModels;
        }

        // POST api/values
        [Route("products/saveRecord")]
        [HttpPost]
        public void Post([FromBody] CategoryProductRequest value)
        {
            using (ECommerceDBEntities context = new ECommerceDBEntities())
            {
                var addedCategory = context.Categories.Add(new Category { CategoryName = value.category.categoryName , CreatedDate = DateTime.Now });
                context.SaveChanges();

                context.Products.Add(new Product { ProductName = value.product.productName , ProductDescription =value.product.productDescription , Product_CategoryId = addedCategory.CategoryId });
                context.SaveChanges();


            }
        }

        /// <summary>
        /// Updating record
        /// </summary>
        /// <param name="productRequest"></param>
        /// <returns></returns>
        [Route("products/updaterecord")]
        [HttpPut]
        public HttpResponseMessage Put([FromBody] ProductRequest productRequest)
        {
            ResponseModel responseModel = new ResponseModel();
            if (!ModelState.IsValid)
            {
                
                responseModel.Message = ModelState.Values.FirstOrDefault().Errors.FirstOrDefault().ErrorMessage;
                responseModel.StatusCode = HttpStatusCode.BadRequest.ToString();
                responseModel.IsSuccess = false;
                

            }
            else
            {
                using (ECommerceDBEntities context = new ECommerceDBEntities())
                {
                    var product = context.Products.Where(c => c.ProductId == productRequest.productid).FirstOrDefault();

                    if (product != null)
                    {
                        product.ProductName = productRequest.productName;
                        product.ProductDescription = productRequest.productDescription;
                        context.SaveChanges();
                        responseModel.Message = "Record updated succesfully for productid : " + productRequest.productid;
                        responseModel.StatusCode = HttpStatusCode.OK.ToString();
                        responseModel.IsSuccess = true;
                    }
                }
            }
            return Request.CreateResponse<ResponseModel>(HttpStatusCode.OK, responseModel);
        }


        [Route("products/{id:int:min(1):max(100)}/deletecategory")]
        [HttpDelete]
        public HttpResponseMessage Delete([FromUri]  int id)
        {
            ResponseModel responseModel = new ResponseModel();
            try
            {
              
                using (ECommerceDBEntities context = new ECommerceDBEntities())
                {
                    var category = context.Categories.Where(c => c.CategoryId == id).FirstOrDefault();

                    if (category != null)
                    {
                        context.Categories.Remove(category);

                        var products = context.Products.Where(c => c.Product_CategoryId == id).ToList();

                        if (products != null && products.Count > 0)
                        {
                            context.Products.RemoveRange(products);
                        }
                        context.SaveChanges();
                        responseModel.Message = "Success";
                        responseModel.StatusCode = HttpStatusCode.OK.ToString();
                        responseModel.IsSuccess = true;
                    }
                    else
                    {
                        responseModel.Message = "Record not found!.";
                        responseModel.StatusCode = HttpStatusCode.NoContent.ToString();
                        responseModel.IsSuccess = true;
                       
                    }

                }
            }
            catch(Exception ex)
            {
                responseModel.Message = "Fail";
                responseModel.StatusCode = HttpStatusCode.InternalServerError.ToString();
                responseModel.IsSuccess = false;
                responseModel.ErrorDescription = ex.StackTrace;

            }
          return  Request.CreateResponse<ResponseModel>(HttpStatusCode.OK, responseModel);
        }

        /// <summary>
        /// Simplilearn Addition
        /// </summary>
        private  static void Add()
        {

        }
    }
}
