﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace Session3_Scafolding.Models
{
    public class StudentViewModel
    {
        public int Studentid { get; set; } // Automatic properties
      
        [Required(ErrorMessage = "Studentname is required")]
        [StringLength(10)]
        public string StudentName { get;set; }

        public string ClassName { get; set; }

        public string SchollName { get; set; }

        public string SchoolId { get; set; }
    }
}