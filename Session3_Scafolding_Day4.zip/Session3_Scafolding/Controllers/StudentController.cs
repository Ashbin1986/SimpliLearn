﻿using DataAccess;
using DataAccess.Repositories;
using Session3_Scafolding.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace Session3_Scafolding.Controllers
{
    public class StudentController : Controller
    {
        // GET: Student
        public ActionResult Index()
        {
            StudentViewModel student = new StudentViewModel();
            return View(student);
        }

        [HttpPost]
        [Authorize(Roles ="Admin")]
        public ActionResult SaveRecord(StudentViewModel studentViewModel)
        {
            IStudentRepository studentRepository = new StudentRepository();
            studentRepository.SaveStudent(new Student
            {
                Class = studentViewModel.ClassName,
                StudentName = studentViewModel.StudentName
            });

            return RedirectToAction("Index");
        }

        public ActionResult StudentsView()
        {
            IStudentRepository studentRepository = new StudentRepository();

            var lstStudents = studentRepository.GetStudents(); // received from DB

            List<StudentViewModel> studentViewModels = new List<StudentViewModel>(); // Building for UI

            foreach (var student in lstStudents)
            {
                studentViewModels.Add(new StudentViewModel
                {
                    ClassName = student.Class,
                    StudentName = student.StudentName,
                    Studentid = student.Studentid,
                    SchollName = student.School.SchoolName,
                    SchoolId = student.School.SchoolId.ToString()

                });
            }

            return View(studentViewModels);
        }



        public ActionResult DeleteRecord(int id)
        {
            IStudentRepository studentRepository = new StudentRepository();
            studentRepository.DeleteById(id);

            return RedirectToAction("StudentsView");
        }

        public ActionResult Details(int id)
        {
            IStudentRepository studentRepository = new StudentRepository();
            var student = studentRepository.GetStudentById(id);
            StudentViewModel studentViewModel = new StudentViewModel
            {
                ClassName = student.Class,
                SchollName = student.School.SchoolName,
                StudentName = student.StudentName
            };

            return View(studentViewModel);
        }
    }
}