﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataAccess.Repositories
{
    public interface IStudentRepository
    {
        void SaveStudent(Student student);

        Student Update(Student student);

        void DeleteById(int studentId);

        Student GetStudentById(int studentId);
        List<Student> GetStudents();
    }
}
