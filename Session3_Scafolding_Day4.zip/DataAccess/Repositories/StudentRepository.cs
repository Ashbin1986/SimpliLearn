﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataAccess.Repositories
{
    public class StudentRepository : IStudentRepository
    {
        public void DeleteById(int studentId)
        {
            using(SchoolManagementEntities ctx = new SchoolManagementEntities())
            {
                var studentEntity = ctx.Students.Where(c => c.Studentid == studentId).FirstOrDefault();
                if (studentEntity != null)
                {
                    ctx.Students.Remove(studentEntity);
                }
                ctx.SaveChanges();

            }
        }

        public Student GetStudentById(int studentId)
        {
            using (SchoolManagementEntities ctx = new SchoolManagementEntities())
            {
                var records = from m in ctx.Students select m;

                var studentDetails  = ctx.Students.Where(c => c.Studentid == studentId).FirstOrDefault();

                var school = ctx.Schools.Where(c => c.SchoolId == studentDetails.SchoolId).FirstOrDefault();
                studentDetails.School = school;

                return studentDetails;
            }
        }

        public List<Student> GetStudents()
        {
            using (SchoolManagementEntities ctx = new SchoolManagementEntities())
            {
                var studentResult = ctx.Students.ToList(); 
                foreach(var student in studentResult)
                {
                    var school = ctx.Schools.Where(c => c.SchoolId == student.SchoolId).FirstOrDefault();
                    student.School = school;
                }

                return studentResult;
            }
        }

        public void SaveStudent(Student student)
        {
            using (SchoolManagementEntities ctx = new SchoolManagementEntities())
            {
                ctx.Students.Add(student);
                ctx.SaveChanges();
            }
          
        }

        public Student Update(Student student)
        {
            using (SchoolManagementEntities ctx = new SchoolManagementEntities())
            {
                var studentEntity = ctx.Students.Where(c => c.Studentid == student.Studentid).FirstOrDefault();
                if (studentEntity != null)
                {
                    studentEntity.StudentName = student.StudentName;
                }
                ctx.SaveChanges();
                return studentEntity;

            }
        }
    }
}
